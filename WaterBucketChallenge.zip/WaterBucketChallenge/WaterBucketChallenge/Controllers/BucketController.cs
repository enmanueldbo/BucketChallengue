﻿using Microsoft.AspNetCore.Mvc;
using System.Text.Json;
using WaterBucketChallenge.Models;

// For more information on enabling Web API for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace WaterBucketChallenge.Controllers
{
    [Route("[controller]")]
    [ApiController]
    public class BucketController : ControllerBase
    {
        // GET: api/<BucketController>
        [HttpGet]
        public IEnumerable<string> Get()
        {
            return new string[] { "value1", "value2" };
        }

        // GET api/<BucketController>/5
        [HttpGet("{id}")]
        public string Get(int id)
        {
            return "value";
        }

        // POST api/<BucketController>
        [HttpPost]
        public string Post([FromBody] WaterJug waterJugs)
        {
            if (!ModelState.IsValid)
            {
                return JsonSerializer.Serialize(BadRequest(ModelState));
            }

            if (( waterJugs.z_amount_wanted % waterJugs.x_capacity == 0 || waterJugs.z_amount_wanted % waterJugs.y_capacity == 0) 
                &&(waterJugs.x_capacity >= waterJugs.z_amount_wanted || waterJugs.y_capacity >= waterJugs.z_amount_wanted))
            {

                List<Response> responses = new List<Response>();
                Bucket x = new Bucket { GallonCapacity = waterJugs.x_capacity, Name = "X" };
                Bucket y = new Bucket { GallonCapacity = waterJugs.y_capacity, Name = "Y" };
               /* BucketRepository bucketRepository = new BucketRepository();
                /*while (y.GallonQuantity != waterJugs.z_amount_wanted && x.GallonQuantity != waterJugs.z_amount_wanted)
                {
                    if (x.GallonQuantity == 0)
                        x.Fill(x.GallonCapacity, responses, x, y);
                    x.Transfer(y, x.GallonQuantity, responses,x , y);

                }*/
         /*       if (waterJugs.x_capacity - waterJugs.z_amount_wanted < waterJugs.y_capacity - waterJugs.z_amount_wanted)
                    bucketRepository.Process(x, y, waterJugs.z_amount_wanted, responses);
                else
                    bucketRepository.Process(y, x, waterJugs.z_amount_wanted, responses);*/
                return JsonSerializer.Serialize(responses);
            }
          /*  else if (y_capacity % z_amount_wanted == 0)
            {
                null;
            }*/

            else
            {
                return JsonSerializer.Serialize("No Solution");
            }
        }

        // PUT api/<BucketController>/5
        [HttpPut("{id}")]
        public void Put(int id, [FromBody] string value)
        {
        }

        // DELETE api/<BucketController>/5
        [HttpDelete("{id}")]
        public void Delete(int id)
        {
        }
    }
}
